AddCSLuaFile()

if SERVER then return end


hook.Add("InitPostEntity", "welcome_message_uzi", function()
	
	timer.Simple(1, function()
		local ply = LocalPlayer()
		local message = string.format([[
		-----------------------------
		[Undertale Dialog Box] Welcome %s
		ConVars:
		'db_admin <0|1>' - Toggles admin only mode.
		'db_expression' - Toggles the expression menu (you can select your expression from the vgui)
		Commands:
		'db_expression <expression>' - Sets facial expression
		'db_font <font>' - Sets text font
		'/db <speed|text> <text>' - Creates dialog box with set speed and text (default speed 1)
		'/db [1] text goes here - it waits a second before your text displays in the dialog box (default speed 1, delay can go up to 5 seconds)
	    '/db[r]text goes here[/r] - Change the text color in the Dialog Box (there is r,y,b,lb,g,p,o,gd) (replace [r] and, [/r] with any of the colors you would like)
		Example: 'db_expression sans_4', 'db_font sans', 'db 0.5 Test message'
		You can use '\n' inside a message to make a new line.
		-----------------------------
		]], ply:Nick())

		ply:ChatPrint(message)
	end)

end)