AddCSLuaFile()
local admin = CreateConVar("db_admin", "1", {FCVAR_ARCHIVE,FCVAR_REPLICATED}, "Makes dialog box admin only.", 0, 1)
local TagColors = {
	["w"] = Color(255, 255, 255),
	["r"] = Color(255, 0, 0),
	["y"] = Color(255, 255, 0),
	["b"] = Color(0, 0, 255),
	["lb"] = Color(0, 200, 255),
	["g"] = Color(0, 255, 0),
	["p"] = Color(255, 0, 255),
	["o"] = Color(255, 165, 0),
	["gd"] = Color(255, 215, 0),
}
local function AddExpressions(tbl, path, prefix)
	local separator = (path ~= "" and path:sub(-1) ~= "/") and "/" or ""
	local searchPattern = path .. separator .. "*.png"
	local files = file.Find(searchPattern, "GAME")
	if not files or #files == 0 then return end
	table.sort(files)
	for i, filename in ipairs(files) do
		local fullPath = path .. separator .. filename
		local key = prefix .. "_" .. i
		tbl[key] = fullPath
	end
end
local Expressions = {}
AddExpressions(Expressions, "materials/db/alphys", "alphys")
AddExpressions(Expressions, "materials/db/asgore", "asgore")
AddExpressions(Expressions, "materials/db/asriel", "asriel")
AddExpressions(Expressions, "materials/db/hyperasriel", "hyperasriel")
AddExpressions(Expressions, "materials/db/flowey", "flowey")
AddExpressions(Expressions, "materials/db/gasterblaster", "gasterblaster")
AddExpressions(Expressions, "materials/db/chara", "chara")
AddExpressions(Expressions, "materials/db/mettaton", "mettaton")
AddExpressions(Expressions, "materials/db/papyrus", "papyrus")
AddExpressions(Expressions, "materials/db/sans", "sans")
AddExpressions(Expressions, "materials/db/toriel", "toriel")
AddExpressions(Expressions, "materials/db/undyne", "undyne")
local Eggs = {
	["uzi"] = {
		speed = 1.5,
		expression = "materials/db/uzi.png",
		font = "determination",
		sound = "db/uzi.wav",
		text = "[p]Bite me![/p]",
		character = "uzi",
	},
	["tonk"] = {
		speed = 0.5,
		expression = "materials/db/tonk/tonk.png",
		font = "determination",
		sound = "db/tonk.wav",
		text = "[g]Hello son as you can see.[0.8]\nI am a tank that can speak.[/g]",
		character = "tonk",
	},
	["n"] = {
		speed = 0.4,
		expression = "materials/db/n.png",
		font = "determination",
		sound = "db/n.wav",
		text = "[y]Theres no escaping.[0.5]\nFrom the inferno.[/y]",
		character = "n",
	},
}
for _, t in pairs(Eggs) do
	resource.AddFile(t.expression)
end
local Sounds = {
	["alphys"] = "db/snd_txtal.wav",
	["asgore"] = "db/snd_txtasg.wav",
	["asriel"] = "db/snd_txtasr.wav",
	["hyperasriel"] = "db/snd_txtasr2.wav",
	["flowey"] = "db/snd_floweytalk1.wav",
	["gasterblaster"] = "db/gasterblaster_charging.wav",
	["chara"] = "db/snd_txt1.wav",
	["mettaton"] = "db/snd_mtt1.wav",
	["papyrus"] = "db/snd_txtpap.wav",
	["sans"] = "db/snd_txtsans.wav",
	["toriel"] = "db/snd_txttor.wav",
	["undyne"] = "db/snd_txtund.wav",
}
local Fonts = {
	["alphys"] = "alphys",
	["asgore"] = "UndertaleFont",
	["asriel"] = "UndertaleFont",
	["flowey"] = "determination",
	["gasterblaster"] = "determination",
	["chara"] = "determination",
	["mettaton"] = "mettaton",
	["papyrus"] = "papyrus ut",
	["sans"] = "comic sans ms",
	["toriel"] = "toriel",
	["undyne"] = "undyne",
}
local SingleTime = {
	["gasterblaster"] = true,
	["uzi"] = true,
	["n"] = true,
	["tonk"] = true,
}
local resource_fonts = {
	"8bitoperator jve.ttf",
	"alphys.ttf",
	"axis.ttf",
	"bratty & catty.ttf",
	'Comic Sans MS.ttf',
	"determination.ttf",
	"kanako.ttf",
	"mettaton ex.ttf",
	"mettaton.ttf",
	"napstablook.ttf",
	'papyrus ut.ttf',
	'pixel operator.ttf',
	'save.ttf',
	'snowdin.ttf',
	'starlo-sheriff.ttf',
	'toriel.ttf',
	'undyne.ttf',
}
if SERVER then
	for _, v in ipairs(resource_fonts) do
		resource.AddFile(v)
	end
	for _, v in pairs(Sounds) do
		resource.AddFile(v)
	end
	for _, v in pairs(Expressions) do
		resource.AddFile(v)
	end
	util.AddNetworkString("db_server")
	util.AddNetworkString("db_client")
	net.Receive("db_server", function(len, ply)
		if !admin:GetBool() or ply:IsAdmin() then
			local ex = net.ReadString()
			local f = net.ReadString()
			local speed = math.max(net.ReadFloat(), 0.2)
			local text = net.ReadString()
			local egg = Eggs[ex]
			if #ex > 0 and !Expressions[ex] and !egg then
				ex = ""
			end
			if #f > 0 and !Fonts[f] or #f == 0 then
				f = "asriel"
			end
			local sound = "asriel"
			local character = ""
			if !egg then
				for key, snd in pairs(Sounds) do
					if ex:StartsWith(key) then
						sound = snd
						character = key
						break
					end
				end
				f = Fonts[f] or ""
				ex = Expressions[ex] or ""
			else
				speed = egg.speed
				ex = egg.expression
				sound = egg.sound
				character = egg.character
				f = egg.font
				text = egg.text
			end
			net.Start("db_client")
				net.WriteString(ex)
				net.WriteString(f)
				net.WriteFloat(speed)
				net.WriteString(text)
				net.WriteString(sound)
				net.WriteString(character)
			net.Broadcast()
		end
	end)
	local function HandleArgs(args)
		local speed = tonumber(args[2])
		local text = ""
		local isText = false
		if type(speed) == "nil" then
			speed = 1
			isText = true
		end
		if isText then
			text = table.concat(args, " ", 2)
		else
			text = table.concat(args, " ", 3)
		end
		return text, math.max(speed, 0.2)
	end
	hook.Add("PlayerSay", "dialog_box", function(ply, text)
		local args = string.Split(text, " ")
		if #args >= 1 then
			if args[1] == "/db_expression" then
				ply:ConCommand("db_expression " .. (args[2] or ""))
				return ""
			end
			if args[1] == "!db_expression" then
				ply:ConCommand("db_expression " .. (args[2] or ""))
				return
			end
			if args[1] == "/db_font" then
				ply:ConCommand("db_font " .. (args[2] or ""))
				return ""
			end
			if args[1] == "!db_font" then
				ply:ConCommand("db_font " .. (args[2] or ""))
				return
			end
		end
		if #args >= 2 then
			if args[1] == "/db" then
				local t, s = HandleArgs(args)
				ply:ConCommand("db " .. s .. " " .. t)
				return ""
			end
			if args[1] == "!db" then
				local t, s = HandleArgs(args)
				ply:ConCommand("db " .. s .. " " .. t)
				return ""
			end
		end
	end)
end
if CLIENT then
	local queue = {}
	local curMsg = nil
	local BASE_CHAR_TIME = 0.033
	local function ParseTextSegments(text)
		text = string.Replace(text, "\\n", "\n")
		local segments = {}
		local delays = {}
		local current = {text = "", color = TagColors["w"]}
		local i = 1
		while i <= #text do
			if text:sub(i, i) == "[" then
				local tagStart = i
				local tagEnd = text:find("]", i)
				if tagEnd then
					local tagContent = text:sub(i+1, tagEnd-1)
					local isClosing = tagContent:sub(1,1) == "/"
					if isClosing then
						local tagName = tagContent:sub(2):lower()
						if #current.text > 0 then
							table.insert(segments, current)
							current = {text = "", color = TagColors["w"]}
						end
						i = tagEnd + 1
					else
						local delayTime = tonumber(tagContent)
						if delayTime then
							delayTime = math.min(delayTime, 5)
							local currentLength = 0
							for _, seg in ipairs(segments) do
								currentLength = currentLength + #seg.text
							end
							currentLength = currentLength + #current.text
							delays[currentLength] = delayTime
							i = tagEnd + 1
						else
							local tagName = tagContent:lower()
							if #current.text > 0 then
								table.insert(segments, current)
							end
							current = {
								text = "",
								color = TagColors[tagName] or TagColors["w"]
							}
							i = tagEnd + 1
						end
					end
				else
					current.text = current.text .. "["
					i = i + 1
				end
			else
				current.text = current.text .. text:sub(i, i)
				i = i + 1
			end
		end
		if #current.text > 0 then
			table.insert(segments, current)
		end
		return segments, delays
	end
	local function WrapTextSegments(segments, maxWidth, font)
		local lines = {}
		local currentLine = {}
		local currentWidth = 0
		for _, seg in ipairs(segments) do
			if seg.text == "\n" then
				if #currentLine > 0 then
					table.insert(lines, currentLine)
					currentLine = {}
					currentWidth = 0
				end
				table.insert(lines, {})
			else
				local text = seg.text
				local startIndex = 1
				while startIndex <= #text do
					local nextSpace = text:find("%s", startIndex)
					local nextNewline = text:find("\n", startIndex)
					local nextBreak
					if nextNewline and (not nextSpace or nextNewline < nextSpace) then
						nextBreak = nextNewline
					else
						nextBreak = nextSpace
					end
					local wordEnd = nextBreak or #text
					local word = text:sub(startIndex, wordEnd)
					surface.SetFont(font)
					local wordWidth = surface.GetTextSize(word)
					if currentWidth + wordWidth <= maxWidth then
						table.insert(currentLine, {
							text = word,
							color = seg.color
						})
						currentWidth = currentWidth + wordWidth
						if nextNewline and nextNewline == wordEnd then
							table.insert(lines, currentLine)
							currentLine = {}
							currentWidth = 0
						end
					else
						if #currentLine > 0 then
							table.insert(lines, currentLine)
							currentLine = {}
							currentWidth = 0
						end
						local charIndex = 1
						while charIndex <= #word do
							local char = word:sub(charIndex, charIndex)
							local charWidth = surface.GetTextSize(char)
							if currentWidth + charWidth > maxWidth then
								table.insert(lines, currentLine)
								currentLine = {}
								currentWidth = 0
							end
							table.insert(currentLine, {
								text = char,
								color = seg.color
							})
							currentWidth = currentWidth + charWidth
							charIndex = charIndex + 1
						end
					end
					startIndex = wordEnd + 1
				end
			end
		end
		if #currentLine > 0 then
			table.insert(lines, currentLine)
		end
		return lines
	end
	surface.CreateFont("UndertaleFont", { 
		font = "8bitoperator JVE",
		size = 40 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("alphys", {
		font = "Alphys",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("axis", {
		font = "AXIS",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("bratty & catty", {
		font = "Bratty & Catty",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("comic sans ms", {
		font = "Comic Sans MS",
		size = 54 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("determination", {
		font = "Determination",
		size = 40 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("kanako", {
		font = "Kanako",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("mettaton ex", {
		font = "Mettaton EX",
		size = 40 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("mettaton", {
		font = "METTATON",
		size = 35 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("napstablook", {
		font = "napstablook",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("papyrus ut", {
		font = "Papyrus UT",
		size = 60 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("pixel operator", {
		font = "Pixel Operator",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("save", {
		font = "SAVE",
		size = 40 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("snowdin", {
		font = "Snowdin",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("starlo-sheriff", {
		font = "Starlo Sheriff",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("toriel", {
		font = "Toriel",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	surface.CreateFont("undyne", {
		font = "Undyne",
		size = 34 * (ScrW() / 1920),
		weight = 500,
		antialias = true,
		shadow = true
	})
	local ex = CreateClientConVar("db_expression_internal", "", true, true)
	local f = CreateClientConVar("db_font_internal", "", true, true)
	local function ShowExpressionMenu()
		local frame = vgui.Create("DFrame")
		frame:SetSize(800, 600)
		frame:SetTitle("Expression Menu")
		frame:Center()
		frame:MakePopup()
		frame.Paint = function(_, w, h)
			surface.SetDrawColor(0, 0, 0, 240)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		local scroll = vgui.Create("DScrollPanel", frame)
		scroll:Dock(FILL)
		local grid = vgui.Create("DGrid", scroll)
		grid:Dock(FILL)
		grid:SetCols(4)
		grid:SetColWide(190)
		grid:SetRowHeight(220)
		local function CreateExpressionPanel(expKey, expPath)
			local charName = expKey:match("^(.-)_%d+$") or ""
			local fontName = charName or "default"
			local panel = vgui.Create("DPanel")
			panel:SetSize(180, 210)
			panel.Paint = function(_, w, h)
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 255, 255)
				surface.DrawOutlinedRect(0, 0, w, h)
			end
			local img = vgui.Create("DImage", panel)
			img:SetSize(100, 100)
			img:SetPos(40, 50)
			img:SetMaterial(Material(expPath))
			local nameLabel = vgui.Create("DLabel", panel)
			nameLabel:SetText(expKey)
			nameLabel:SetFont("UndertaleFont")
			nameLabel:SetTextColor(Color(255, 255, 255))
			nameLabel:SizeToContents()
			nameLabel:SetPos((180 - nameLabel:GetWide()) / 2, 150)
			local fontLabel = vgui.Create("DLabel", panel)
			fontLabel:SetText("Font: " .. fontName)
			fontLabel:SetFont("UndertaleFont")
			fontLabel:SetTextColor(Color(255, 255, 255))
			fontLabel:SizeToContents()
			fontLabel:SetPos((180 - fontLabel:GetWide()) / 2, 175)
			local setExpression = vgui.Create("DButton", panel)
			setExpression:Dock(TOP)
			setExpression:SetText("Set Expression")
			setExpression.DoClick = function()
				ex:SetString(expKey)
				LocalPlayer():ChatPrint("Expression set to: " .. expKey)
			end
			setExpression.Paint = function(self, w, h)
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 255, 255)
				surface.DrawOutlinedRect(0, 0, w, h)
				self:SetTextColor(self:IsHovered() and Color(255, 255, 0) or Color(255, 255, 255))
			end
			local setFont = vgui.Create("DButton", panel)
			setFont:Dock(TOP)
			setFont:SetText("Set Font")
			setFont.DoClick = function()
				if fontName ~= "default" then
					f:SetString(fontName)
					LocalPlayer():ChatPrint("Font set to: " .. fontName)
				end
			end
			setFont.Paint = function(self, w, h)
				surface.SetDrawColor(0, 0, 0, 255)
				surface.DrawRect(0, 0, w, h)
				surface.SetDrawColor(255, 255, 255)
				surface.DrawOutlinedRect(0, 0, w, h)
				self:SetTextColor(self:IsHovered() and Color(255, 255, 0) or Color(255, 255, 255))
			end
			return panel
		end
		local keys = table.GetKeys(Expressions)
		table.sort(keys)
		for _, key in ipairs(keys) do
			grid:AddItem(CreateExpressionPanel(key, Expressions[key]))
		end
	end
	concommand.Add("db_expression", function(_, _, args)
		if #args < 1 then
			ShowExpressionMenu()
		else
			local expression = args[1]
			ex:SetString(expression)
			LocalPlayer():ChatPrint("Expression set to: " .. expression)
		end
	end, function(_, argstr)
		local matches = {}
		local arg = argstr:Trim():lower()
		for exp in pairs(Expressions) do
			if exp:lower():StartsWith(arg) then
				table.insert(matches, "db_expression " .. exp)
			end
		end
		table.sort(matches)
		return matches
	end)
	concommand.Add("db_font", function(_, _, args)
		if #args < 1 then
			LocalPlayer():ChatPrint("Usage: db_font <font>")
			LocalPlayer():ChatPrint("Available fonts: " .. table.concat(table.GetKeys(Fonts), ", "))
			return
		end
		local font = args[1]
		f:SetString(font)
		LocalPlayer():ChatPrint("Font set to: " .. font)
	end, function(_, argstr)
		local matches = {}
		local arg = argstr:Trim():lower()
		for font in pairs(Fonts) do
			if font:lower():StartsWith(arg) then
				table.insert(matches, "db_font " .. font)
			end
		end
		table.sort(matches)
		return matches
	end)
	concommand.Add("db", function(_, _, args)
		if #args == 0 then
			print("Usage: db <speed|text> <text>")
			return
		end
		local ply = LocalPlayer()
		if !admin:GetBool() or ply:IsAdmin() then
			local speed = tonumber(args[1])
			local text
			if speed then
				if #args < 2 then
					LocalPlayer():ChatPrint("Error: Missing text after speed")
					return
				end
				text = table.concat(args, " ", 2)
			else
				speed = 1
				text = table.concat(args, " ", 1)
			end
			speed = math.max(speed, 0.2)
			net.Start("db_server")
				net.WriteString(ex:GetString())
				net.WriteString(f:GetString())
				net.WriteFloat(speed)
				net.WriteString(text)
			net.SendToServer()
		end
	end)
	net.Receive("db_client", function()
		local cex = net.ReadString()
		local cf = net.ReadString()
		local speed = math.max(net.ReadFloat(), 0.2)
		local text = net.ReadString()
		local sound = net.ReadString()
		local character = net.ReadString()
		table.insert(queue, {ex = cex, font = cf, speed = speed, text = text, sound = sound, character = character})
	end)
	hook.Add("HUDPaint", "db_andiseered", function()
		local w, h = ScrW(), ScrH()
		local scaleX, scaleY = w/1280, h/720
		local dx, dy = scaleX * 640, scaleY * 128
		local padding = 20 * scaleX
		local imageWidth = 128 * scaleX
		local textAreaWidth = dx - imageWidth - padding * 2
		if not curMsg and #queue > 0 then
			curMsg = table.remove(queue, 1)
			curMsg.startTime = CurTime()
			curMsg.charDelay = BASE_CHAR_TIME / curMsg.speed
			local segments, delays = ParseTextSegments(curMsg.text)
			curMsg.segments = segments
			curMsg.delays = delays
			curMsg.cleanedText = ""
			for _, seg in ipairs(segments) do
				curMsg.cleanedText = curMsg.cleanedText .. seg.text
			end
			local charTimes = {}
			charTimes[0] = 0
			for i=1, #curMsg.cleanedText do
				charTimes[i] = charTimes[i-1] + curMsg.charDelay
				if delays[i-1] then
					charTimes[i] = charTimes[i] + delays[i-1]
				end
			end
			curMsg.charTimes = charTimes
			curMsg.wrappedLines = WrapTextSegments(segments, textAreaWidth, curMsg.font)
			curMsg.lineHeight = draw.GetFontHeight(curMsg.font)
			curMsg.charCount = #curMsg.cleanedText
			curMsg.endTime = curMsg.startTime + charTimes[#curMsg.cleanedText] + 3
			curMsg.lastSoundTime = 0
			curMsg.lastSoundChar = 0
			local minHeight = dy
			local contentHeight = #curMsg.wrappedLines * curMsg.lineHeight + padding * 2
			curMsg.boxHeight = math.max(minHeight, contentHeight)
			if SingleTime[curMsg.character] then
				surface.PlaySound(curMsg.sound)
			end
		end
		if curMsg then
			local now = CurTime()
			if now >= curMsg.endTime then
				curMsg = nil
				return
			end
			local elapsed = now - curMsg.startTime
			local totalChars = 0
			for i=1, curMsg.charCount do
				if elapsed >= curMsg.charTimes[i] then
					totalChars = i
				else
					break
				end
			end
			if not SingleTime[curMsg.character] and curMsg.charCount > 0 and totalChars > 0 then
				if totalChars > curMsg.lastSoundChar then
					for i = curMsg.lastSoundChar + 1, totalChars do
						local char = curMsg.cleanedText:sub(i, i)
						if char ~= " " and char ~= "\n" and char ~= "\t" then
							surface.PlaySound(curMsg.sound)
							curMsg.lastSoundChar = i
							break
						end
					end
				end
			end
			local boxY = h - curMsg.boxHeight - 25
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawRect(dx / 2, boxY, dx, curMsg.boxHeight)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawOutlinedRect(dx / 2, boxY, dx, curMsg.boxHeight, 4)
			if curMsg.ex and curMsg.ex ~= "" and curMsg.ex ~= "uzi" and curMsg.ex ~= "n" then
				local mat = Material(curMsg.ex)
				if mat and not mat:IsError() then
					local imgSize = math.min(imageWidth - padding * 2, curMsg.boxHeight - padding * 2)
					local imgX = dx / 2 + padding
					local imgY = boxY + (curMsg.boxHeight - imgSize) / 2
					surface.SetMaterial(mat)
					surface.SetDrawColor(255, 255, 255, 255)
					surface.DrawTexturedRect(imgX, imgY, imgSize, imgSize)
				end
			end
			local textStartX = dx / 2 + imageWidth + padding
			local textStartY = boxY + padding
			draw.SimpleText("	* ", curMsg.font, textStartX - 50, textStartY, Color(255, 255, 255))
			local charCounter = 0
			for lineIndex, line in ipairs(curMsg.wrappedLines) do
				local lineX = textStartX
				local lineY = textStartY + (lineIndex - 1) * curMsg.lineHeight
				for segIndex, seg in ipairs(line) do
					local segText = seg.text
					local visibleChars = math.max(0, totalChars - charCounter)
					if visibleChars > 0 then
						local visibleText = visibleChars >= #segText and segText or 
											segText:sub(1, visibleChars)
						draw.SimpleText(visibleText, curMsg.font, lineX, lineY, seg.color)
						lineX = lineX + surface.GetTextSize(visibleText)
					end
					charCounter = charCounter + #segText
					if charCounter >= totalChars then break end
				end
				if charCounter >= totalChars then break end
			end
		end
	end)
end